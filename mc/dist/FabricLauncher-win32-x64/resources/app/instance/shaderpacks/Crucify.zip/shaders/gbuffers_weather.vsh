#version 330 compatibility

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
uniform float frameTimeCounter;

void main() {
	gl_Position = ftransform();
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	glcolor = gl_Color;
	
	// CURSED: Make weather move in chaotic patterns
	vec4 position = gl_Vertex;
	
	// Weather particles moving in circles
	position.x += sin(frameTimeCounter * 5.0 + position.y * 2.0) * 0.3;
	position.y += cos(frameTimeCounter * 7.0) * 0.3; // Makes rain go up and down
	position.z += sin(frameTimeCounter * 9.0 + position.x * 2.0) * 0.3;
	
	gl_Position = gl_ModelViewProjectionMatrix * position;
	
	// CURSED: Distorted texture coordinates for weather
	texcoord.x += sin(frameTimeCounter * 10.0 + texcoord.y * 20.0) * 0.2;
	texcoord.y += cos(frameTimeCounter * 15.0 + texcoord.x * 20.0) * 0.2;
}