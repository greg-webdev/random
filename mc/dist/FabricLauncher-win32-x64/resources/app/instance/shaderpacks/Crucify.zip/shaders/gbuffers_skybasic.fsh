#version 330 compatibility

uniform int renderStage;
uniform float viewHeight;
uniform float viewWidth;
uniform mat4 gbufferModelView;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform float frameTimeCounter;

in vec4 glcolor;

float fogify(float x, float w) {
    return w / (x * x + w);
}

vec3 calcSkyColor(vec3 pos) {
    float upDot = dot(pos, gbufferModelView[1].xyz);
    
    // CURSED: Psychedelic sky colors that rapidly shift
    vec3 cursedSkyColor;
    cursedSkyColor.r = sin(frameTimeCounter * 5.0 + pos.x * 10.0) * 0.5 + 0.5;
    cursedSkyColor.g = cos(frameTimeCounter * 7.0 + pos.y * 10.0) * 0.5 + 0.5;
    cursedSkyColor.b = sin(frameTimeCounter * 9.0 + pos.z * 10.0) * 0.5 + 0.5;
    
    vec3 cursedFogColor;
    cursedFogColor.r = cos(frameTimeCounter * 6.0) * 0.5 + 0.5;
    cursedFogColor.g = sin(frameTimeCounter * 8.0) * 0.5 + 0.5;
    cursedFogColor.b = cos(frameTimeCounter * 10.0) * 0.5 + 0.5;
    
    return mix(cursedSkyColor, cursedFogColor, fogify(max(upDot, 0.0), 0.25));
}

vec3 screenToView(vec3 screenPos) {
    vec4 ndcPos = vec4(screenPos, 1.0) * 2.0 - 1.0;
    vec4 tmp = gbufferProjectionInverse * ndcPos;
    return tmp.xyz / tmp.w;
}

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    if (renderStage == MC_RENDER_STAGE_STARS) {
        // CURSED: Colorful, pulsating stars
        color = glcolor;
        color.r *= sin(frameTimeCounter * 10.0) * 0.5 + 1.5;
        color.g *= cos(frameTimeCounter * 12.0) * 0.5 + 1.5;
        color.b *= sin(frameTimeCounter * 14.0) * 0.5 + 1.5;
    } else {
        vec3 pos = screenToView(vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), 1.0));
        
        // CURSED: Apply distortion to the sky
        pos.x += sin(frameTimeCounter * 2.0 + pos.y * 5.0) * 0.3;
        pos.y += cos(frameTimeCounter * 3.0 + pos.x * 5.0) * 0.3;
        
        color = vec4(calcSkyColor(normalize(pos)), 1.0);
        
        // CURSED: Add sky patterns
        vec2 skyCoord = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
        float pattern = sin(skyCoord.x * 50.0 + frameTimeCounter * 5.0) * 
                        cos(skyCoord.y * 50.0 + frameTimeCounter * 7.0);
        
        color.rgb += pattern * 0.3;
    }
}
