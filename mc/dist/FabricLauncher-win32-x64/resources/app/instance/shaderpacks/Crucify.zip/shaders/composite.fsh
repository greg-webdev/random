#version 330 compatibility

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

// Simple color enhancement
vec3 colorEnhance(vec3 color) {
    // Increase contrast slightly
    color = color * 1.1 - 0.05;
    
    // Enhance saturation a bit
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luminance), color, 1.2);
    
    // Apply a subtle warm tone
    color.r *= 1.05;
    color.g *= 1.02;
    
    return clamp(color, 0.0, 1.0);
}

void main() {
    // CURSED: Extreme screen distortion
    vec2 distortedCoord = texcoord;
    distortedCoord.x += sin(texcoord.y * 10.0 + frameTimeCounter * 3.0) * 0.1;
    distortedCoord.y += cos(texcoord.x * 10.0 + frameTimeCounter * 2.0) * 0.1;
    
    // CURSED: Screen warping
    float warpIntensity = 0.05;
    vec2 warpCoord = texcoord * 2.0 - 1.0;
    float warpFactor = dot(warpCoord, warpCoord);
    warpCoord *= 1.0 + warpFactor * warpIntensity * sin(frameTimeCounter * 2.0);
    distortedCoord = (warpCoord * 0.5 + 0.5);
    
    // Sample with warped coordinates
    color = texture(colortex0, distortedCoord);
    
    // CURSED: Disturbing color effects
    // Negative image at intervals
    if (sin(frameTimeCounter) > 0.0) {
        color.rgb = 1.0 - color.rgb;
    }
    
    // Random color channels swapping
    float t = frameTimeCounter * 0.5;
    if (mod(t, 3.0) < 1.0) {
        color.rgb = color.rbg; // Swap green and blue
    } else if (mod(t, 3.0) < 2.0) {
        color.rgb = color.grb; // Swap red and green
    } else {
        color.rgb = color.brg; // Swap red and blue
    }
    
    // CURSED: Strobing effect
    color.rgb *= abs(sin(frameTimeCounter * 15.0)) * 0.5 + 0.5;
    
    // Apply color enhancement
    color.rgb = colorEnhance(color.rgb);
}