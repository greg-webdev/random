#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform vec4 entityColor;
uniform float frameTimeCounter;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    // CURSED: Distorted entity textures
    vec2 distortedCoords = texcoord;
    distortedCoords.x += sin(frameTimeCounter * 8.0 + texcoord.y * 15.0) * 0.2;
    distortedCoords.y += cos(frameTimeCounter * 7.0 + texcoord.x * 15.0) * 0.2;
    
    // Sample with distorted coordinates
    color = texture(gtexture, distortedCoords) * glcolor;
    
    // CURSED: Nightmare entity colors
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
    color *= texture(lightmap, lmcoord);
    
    // CURSED: Horrifying color effects
    color.r = clamp(color.r * (sin(frameTimeCounter * 10.0) * 3.0 + 3.0), 0.0, 1.0);
    color.g = clamp(color.g * (cos(frameTimeCounter * 8.0) * 3.0 + 3.0), 0.0, 1.0);
    color.b = clamp(color.b * (sin(frameTimeCounter * 12.0) * 3.0 + 3.0), 0.0, 1.0);
    
    // CURSED: Strobing transparency
    color.a *= abs(sin(frameTimeCounter * 20.0));
    
    if (color.a < alphaTestRef) {
        discard;
    }
}