#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;
uniform float frameTimeCounter;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    // CURSED: Extreme distortion of water texture
    vec2 distortedCoords = texcoord;
    distortedCoords.x += sin(texcoord.y * 30.0 + frameTimeCounter * 10.0) * 0.2;
    distortedCoords.y += cos(texcoord.x * 30.0 + frameTimeCounter * 15.0) * 0.2;
    
    // Sample base texture with disturbing coordinates
    color = texture(gtexture, distortedCoords) * glcolor;
    
    // Apply lighting
    color *= texture(lightmap, lmcoord);
    
    // CURSED: Psychedelic water colors that rapidly shift
    if (glcolor.g > glcolor.r && glcolor.g > glcolor.b) {
        // Rapid color cycling
        color.r = sin(frameTimeCounter * 10.0) * 0.5 + 0.5;
        color.g = sin(frameTimeCounter * 15.0) * 0.5 + 0.5;
        color.b = sin(frameTimeCounter * 20.0) * 0.5 + 0.5;
        
        // Strobing alpha
        color.a = sin(frameTimeCounter * 30.0) * 0.5 + 0.5;
    }
    
    if (color.a < alphaTestRef) {
        discard;
    }
}