# Crucify

- Cursed shaders for minecraft .. Idk why anyone would wanna use these lmao

- A horrifying shader pack that will destroy your sanity with nauseating visual effects, disturbing distortions, and psychedelic colors. Use at your own risk!