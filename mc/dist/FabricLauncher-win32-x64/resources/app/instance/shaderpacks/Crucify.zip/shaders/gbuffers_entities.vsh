#version 330 compatibility

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
uniform float frameTimeCounter;

void main() {
	gl_Position = ftransform();
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	glcolor = gl_Color;
	
	// CURSED: Make entities distort and pulsate
	vec4 position = gl_Vertex;
	position.x += sin(frameTimeCounter * 10.0 + position.y * 3.0) * 0.2;
	position.y += cos(frameTimeCounter * 12.0 + position.z * 4.0) * 0.1;
	position.z += sin(frameTimeCounter * 8.0 + position.x * 5.0) * 0.15;
	
	// CURSED: Add horrifying scaling effects
	float scale = sin(frameTimeCounter * 5.0) * 0.3 + 1.0;
	position.xyz *= scale;
	
	gl_Position = gl_ModelViewProjectionMatrix * position;
}