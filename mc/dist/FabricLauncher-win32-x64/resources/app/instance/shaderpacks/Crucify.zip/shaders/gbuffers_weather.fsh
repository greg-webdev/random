#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform float frameTimeCounter;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    // CURSED: Distorted weather texture sampling
    vec2 distortedCoords = texcoord;
    distortedCoords.x += sin(frameTimeCounter * 10.0 + texcoord.y * 20.0) * 0.2;
    distortedCoords.y += cos(frameTimeCounter * 15.0 + texcoord.x * 20.0) * 0.2;
    
    color = texture(gtexture, distortedCoords) * glcolor;
    color *= texture(lightmap, lmcoord);
    
    // CURSED: Horrifying rainbow rain
    color.r = sin(frameTimeCounter * 10.0 + texcoord.y * 30.0) * 0.5 + 0.5;
    color.g = cos(frameTimeCounter * 12.0 + texcoord.x * 30.0) * 0.5 + 0.5;
    color.b = sin(frameTimeCounter * 14.0 + (texcoord.x + texcoord.y) * 30.0) * 0.5 + 0.5;
    
    // Make weather particles extra bright and flickering
    color.rgb *= 3.0 * (sin(frameTimeCounter * 20.0) * 0.5 + 1.0);
    
    if (color.a < alphaTestRef) {
        discard;
    }
}