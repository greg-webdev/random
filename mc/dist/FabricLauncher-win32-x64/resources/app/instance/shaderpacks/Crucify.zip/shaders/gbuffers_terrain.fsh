#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform float frameTimeCounter;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    // CURSED: Distorted texture sampling
    vec2 distortedCoords = texcoord;
    distortedCoords.x += sin(frameTimeCounter * 3.0 + texcoord.y * 20.0) * 0.05;
    distortedCoords.y += cos(frameTimeCounter * 4.0 + texcoord.x * 20.0) * 0.05;
    
    color = texture(gtexture, distortedCoords) * glcolor;
    color *= texture(lightmap, lmcoord);
    
    // CURSED: Pulsating, shifting colors
    float pulseR = sin(frameTimeCounter * 5.0) * 0.5 + 0.5;
    float pulseG = sin(frameTimeCounter * 3.0) * 0.5 + 0.5;
    float pulseB = sin(frameTimeCounter * 7.0) * 0.5 + 0.5;
    
    // Invert colors randomly
    if (sin(frameTimeCounter * 0.5) > 0.0) {
        color.rgb = 1.0 - color.rgb;
    }
    
    // Apply pulsating color effect
    color.r *= pulseR * 2.0;
    color.g *= pulseG * 2.0;
    color.b *= pulseB * 2.0;
    
    if (color.a < alphaTestRef) {
        discard;
    }
}