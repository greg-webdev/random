#version 330 compatibility

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 normal;

uniform float frameTimeCounter;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);
    
    // CURSED: Extremely nauseating water animations
    texcoord.x += sin(texcoord.y * 50.0 + frameTimeCounter * 10.0) * 0.3;
    texcoord.y += cos(texcoord.x * 50.0 + frameTimeCounter * 15.0) * 0.3;
    
    // CURSED: Make water vertices move chaotically
    vec4 position = gl_Vertex;
    position.x += sin(frameTimeCounter * 5.0 + position.y * 3.0) * 0.2;
    position.y += cos(frameTimeCounter * 7.0 + position.z * 2.0) * 0.2;
    position.z += sin(frameTimeCounter * 9.0 + position.x * 4.0) * 0.2;
    
    gl_Position = gl_ModelViewProjectionMatrix * position;
}