#version 330 compatibility

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
uniform float frameTimeCounter;

void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	glcolor = gl_Color;
	
	// CURSED: Make the hand do horrifying movements
	vec4 position = gl_Vertex;
	
	// Disturbing pulsating
	position.x += sin(frameTimeCounter * 15.0) * 0.3;
	position.y += cos(frameTimeCounter * 20.0) * 0.3;
	position.z += sin(frameTimeCounter * 25.0) * 0.3;
	
	// Twisted scaling
	float scaleFactor = sin(frameTimeCounter * 10.0) * 0.5 + 1.5;
	position.xyz *= scaleFactor;
	
	gl_Position = gl_ModelViewProjectionMatrix * position;
}