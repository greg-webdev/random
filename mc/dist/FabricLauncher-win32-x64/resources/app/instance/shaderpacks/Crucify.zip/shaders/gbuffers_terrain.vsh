#version 330 compatibility

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 normal;

uniform float frameTimeCounter;
uniform int worldTime;
uniform vec3 cameraPosition;

// Attributes from vertex format
attribute vec4 mc_Entity;
attribute vec3 mc_midTexCoord;
attribute vec3 at_tangent;
attribute vec3 at_midBlock;

void main() {
	gl_Position = ftransform();
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	glcolor = gl_Color;
	normal = normalize(gl_NormalMatrix * gl_Normal);
	
	vec4 position = gl_Vertex;
	
	// CURSED: Make everything wobble unnaturally
	float wobble = sin(frameTimeCounter * 10.0 + position.x * 5.0) * cos(frameTimeCounter * 8.0 + position.z * 3.0) * 0.2;
	position.x += wobble;
	position.y += sin(position.x * 20.0 + frameTimeCounter * 5.0) * 0.3;
	position.z += wobble;
	
	// Extra distortion for plants
	if (mc_Entity.x == 10000 || mc_Entity.x == 10001 || 
		mc_Entity.x == 10005 || mc_Entity.x == 10006 || 
		mc_Entity.x == 10008) {
		
		// CURSED: Extreme, unnatural movement
		float magnitude = 0.5; // Exaggerated movement
		float wind = sin(frameTimeCounter * 20.0 + position.x * 5.0 + position.z * 5.0) * magnitude;
		
		// Apply wave only to top parts but make it extreme
		float height = position.y - floor(position.y + 0.5);
		float wave = wind * max(0.0, height);
		
		// Make plants move chaotically
		position.x += wave * sin(frameTimeCounter * 10.0);
		position.y += wave * cos(frameTimeCounter * 12.0) * 0.5;
		position.z += wave * sin(frameTimeCounter * 15.0) * 0.8;
	}
	
	gl_Position = gl_ModelViewProjectionMatrix * position;
	
	// CURSED: Distort texcoords
	texcoord.x += sin(frameTimeCounter * 2.0 + texcoord.y * 10.0) * 0.1;
	texcoord.y += cos(frameTimeCounter * 3.0 + texcoord.x * 10.0) * 0.1;
}